package com.amdocs.Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demospringboot1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
