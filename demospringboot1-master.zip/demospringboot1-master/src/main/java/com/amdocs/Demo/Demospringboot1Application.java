package com.amdocs.Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demospringboot1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demospringboot1Application.class, args);
	}

}
